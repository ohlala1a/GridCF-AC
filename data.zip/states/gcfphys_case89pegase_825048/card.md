## A. Topology (stable incident encoding)
Bus 0 (380.0 kV, in_service=true): ['line 57 -> bus 86 (in_service=true)', 'trafo 46 -> bus 40 (in_service=true)']
Bus 1 (150.0 kV, in_service=true): ['line 11 -> bus 19 (in_service=true)', 'line 35 -> bus 34 (in_service=true)', 'line 70 -> bus 41 (in_service=true)', 'line 75 -> bus 60 (in_service=true)', 'line 76 -> bus 51 (in_service=true)', 'trafo 12 -> bus 17 (in_service=true)']
Bus 2 (150.0 kV, in_service=true): ['line 29 -> bus 25 (in_service=true)', 'line 41 -> bus 34 (in_service=true)', 'line 102 -> bus 32 (in_service=true)', 'line 112 -> bus 66 (in_service=true)', 'line 120 -> bus 39 (in_service=true)', 'line 131 -> bus 64 (in_service=true)', 'line 143 -> bus 45 (in_service=true)', 'line 148 -> bus 30 (in_service=true)', 'line 149 -> bus 42 (in_service=true)', 'line 150 -> bus 40 (in_service=true)', 'line 151 -> bus 15 (in_service=true)', 'trafo 34 -> bus 68 (in_service=true)']
Bus 3 (380.0 kV, in_service=true): ['line 155 -> bus 55 (in_service=true)', 'trafo 43 -> bus 27 (in_service=true)']
Bus 4 (380.0 kV, in_service=true): ['line 0 -> bus 31 (in_service=true)', 'line 49 -> bus 43 (in_service=true)', 'line 51 -> bus 43 (in_service=true)', 'line 58 -> bus 10 (in_service=true)', 'line 79 -> bus 75 (in_service=true)', 'line 80 -> bus 62 (in_service=true)', 'line 81 -> bus 88 (in_service=true)', 'line 82 -> bus 70 (in_service=true)', 'line 83 -> bus 55 (in_service=true)', 'line 84 -> bus 47 (in_service=true)', 'line 85 -> bus 59 (in_service=true)', 'trafo 14 -> bus 33 (in_service=true)']
Bus 5 (150.0 kV, in_service=true): ['line 86 -> bus 33 (in_service=true)', 'line 87 -> bus 66 (in_service=true)', 'line 88 -> bus 64 (in_service=true)', 'line 89 -> bus 76 (in_service=true)', 'line 90 -> bus 27 (in_service=true)', 'line 91 -> bus 42 (in_service=true)', 'line 92 -> bus 40 (in_service=true)', 'trafo 8 -> bus 18 (in_service=true)', 'trafo 15 -> bus 46 (in_service=true)', 'trafo 16 -> bus 12 (in_service=true)']
Bus 6 (380.0 kV, in_service=true): ['line 64 -> bus 68 (in_service=true)', 'line 68 -> bus 68 (in_service=true)']
Bus 7 (150.0 kV, in_service=true): ['line 10 -> bus 19 (in_service=true)', 'line 15 -> bus 87 (in_service=true)', 'line 72 -> bus 35 (in_service=true)', 'line 73 -> bus 83 (in_service=true)']
Bus 8 (380.0 kV, in_service=true): ['line 50 -> bus 43 (in_service=true)']
Bus 9 (380.0 kV, in_service=true): ['line 19 -> bus 78 (in_service=true)', 'line 62 -> bus 17 (in_service=true)', 'line 63 -> bus 62 (in_service=true)']
Bus 10 (380.0 kV, in_service=true): ['line 58 -> bus 4 (in_service=true)', 'line 59 -> bus 80 (in_service=true)']
Bus 11 (380.0 kV, in_service=true): ['line 60 -> bus 80 (in_service=true)', 'trafo 11 -> bus 60 (in_service=true)']
Bus 12 (220.0 kV, in_service=true): ['line 3 -> bus 57 (in_service=true)', 'line 53 -> bus 18 (in_service=true)', 'line 125 -> bus 46 (in_service=true)', 'trafo 16 -> bus 5 (in_service=true)', 'trafo 29 -> bus 64 (in_service=true)', 'trafo 32 -> bus 76 (in_service=true)', 'trafo 36 -> bus 75 (in_service=true)', 'trafo 37 -> bus 75 (in_service=true)', 'trafo 38 -> bus 27 (in_service=true)', 'trafo 39 -> bus 42 (in_service=true)']
Bus 13 (150.0 kV, in_service=true): ['line 137 -> bus 76 (in_service=true)', 'trafo 31 -> bus 48 (in_service=true)']
Bus 14 (380.0 kV, in_service=true): ['line 136 -> bus 48 (in_service=true)', 'line 152 -> bus 52 (in_service=true)']
Bus 15 (150.0 kV, in_service=true): ['line 103 -> bus 32 (in_service=true)', 'line 104 -> bus 44 (in_service=true)', 'line 116 -> bus 66 (in_service=true)', 'line 124 -> bus 39 (in_service=true)', 'line 135 -> bus 64 (in_service=true)', 'line 147 -> bus 45 (in_service=true)', 'line 151 -> bus 2 (in_service=true)', 'line 159 -> bus 77 (in_service=true)']
Bus 16 (380.0 kV, in_service=true): ['line 18 -> bus 78 (in_service=true)', 'line 54 -> bus 68 (in_service=true)', 'line 55 -> bus 28 (in_service=true)']
Bus 17 (380.0 kV, in_service=true): ['line 62 -> bus 9 (in_service=true)', 'trafo 12 -> bus 1 (in_service=true)']
Bus 18 (220.0 kV, in_service=true): ['line 2 -> bus 57 (in_service=true)', 'line 52 -> bus 46 (in_service=true)', 'line 53 -> bus 12 (in_service=true)', 'trafo 7 -> bus 43 (in_service=true)', 'trafo 8 -> bus 5 (in_service=true)']
Bus 19 (150.0 kV, in_service=true): ['line 8 -> bus 87 (in_service=true)', 'line 9 -> bus 34 (in_service=true)', 'line 10 -> bus 7 (in_service=true)', 'line 11 -> bus 1 (in_service=true)', 'line 12 -> bus 60 (in_service=true)', 'line 13 -> bus 83 (in_service=true)', 'line 14 -> bus 51 (in_service=true)', 'trafo 3 -> bus 54 (in_service=true)', 'trafo 4 -> bus 69 (in_service=true)']
Bus 20 (380.0 kV, in_service=true): ['line 65 -> bus 68 (in_service=true)', 'line 66 -> bus 53 (in_service=true)', 'line 67 -> bus 56 (in_service=true)']
Bus 21 (380.0 kV, in_service=true): ['trafo 49 -> bus 53 (in_service=true)']
Bus 22 (150.0 kV, in_service=true): ['line 95 -> bus 83 (in_service=true)', 'trafo 17 -> bus 63 (in_service=true)']
Bus 23 (380.0 kV, in_service=true): ['line 93 -> bus 47 (in_service=true)', 'trafo 22 -> bus 46 (in_service=true)']
Bus 24 (380.0 kV, in_service=true): ['line 5 -> bus 54 (in_service=true)', 'line 142 -> bus 68 (in_service=true)', 'trafo 40 -> bus 30 (in_service=true)']
Bus 25 (150.0 kV, in_service=true): ['line 22 -> bus 34 (in_service=true)', 'line 23 -> bus 38 (in_service=true)', 'line 24 -> bus 60 (in_service=true)', 'line 25 -> bus 66 (in_service=true)', 'line 26 -> bus 39 (in_service=true)', 'line 27 -> bus 76 (in_service=true)', 'line 28 -> bus 45 (in_service=true)', 'line 29 -> bus 2 (in_service=true)', 'line 30 -> bus 27 (in_service=true)', 'line 31 -> bus 42 (in_service=true)', 'line 32 -> bus 40 (in_service=true)', 'trafo 5 -> bus 78 (in_service=true)']
Bus 26 (380.0 kV, in_service=true): ['line 71 -> bus 56 (in_service=true)', 'trafo 10 -> bus 35 (in_service=true)']
Bus 27 (150.0 kV, in_service=true): ['line 30 -> bus 25 (in_service=true)', 'line 43 -> bus 34 (in_service=true)', 'line 90 -> bus 5 (in_service=true)', 'line 113 -> bus 66 (in_service=true)', 'line 121 -> bus 39 (in_service=true)', 'line 132 -> bus 64 (in_service=true)', 'line 139 -> bus 76 (in_service=true)', 'line 156 -> bus 42 (in_service=true)', 'line 157 -> bus 40 (in_service=true)', 'trafo 25 -> bus 46 (in_service=true)', 'trafo 38 -> bus 12 (in_service=true)', 'trafo 43 -> bus 3 (in_service=true)']
Bus 28 (380.0 kV, in_service=true): ['line 55 -> bus 16 (in_service=true)', 'trafo 47 -> bus 42 (in_service=true)']
Bus 29 (380.0 kV, in_service=true): ['line 48 -> bus 43 (in_service=true)']
Bus 30 (150.0 kV, in_service=true): ['line 74 -> bus 35 (in_service=true)', 'line 144 -> bus 45 (in_service=true)', 'line 148 -> bus 2 (in_service=true)', 'trafo 40 -> bus 24 (in_service=true)']
Bus 31 (380.0 kV, in_service=true): ['line 0 -> bus 4 (in_service=true)']
Bus 32 (150.0 kV, in_service=true): ['line 98 -> bus 44 (in_service=true)', 'line 99 -> bus 66 (in_service=true)', 'line 100 -> bus 39 (in_service=true)', 'line 101 -> bus 64 (in_service=true)', 'line 102 -> bus 2 (in_service=true)', 'line 103 -> bus 15 (in_service=true)', 'trafo 19 -> bus 36 (in_service=true)']
Bus 33 (150.0 kV, in_service=true): ['line 86 -> bus 5 (in_service=true)', 'trafo 14 -> bus 4 (in_service=true)']
Bus 34 (150.0 kV, in_service=true): ['line 9 -> bus 19 (in_service=true)', 'line 22 -> bus 25 (in_service=true)', 'line 33 -> bus 49 (in_service=true)', 'line 34 -> bus 41 (in_service=true)', 'line 35 -> bus 1 (in_service=true)', 'line 36 -> bus 60 (in_service=true)', 'line 37 -> bus 66 (in_service=true)', 'line 38 -> bus 39 (in_service=true)', 'line 39 -> bus 76 (in_service=true)', 'line 40 -> bus 45 (in_service=true)', 'line 41 -> bus 2 (in_service=true)', 'line 42 -> bus 51 (in_service=true)', 'line 43 -> bus 27 (in_service=true)', 'line 44 -> bus 42 (in_service=true)', 'line 45 -> bus 40 (in_service=true)']
Bus 35 (150.0 kV, in_service=true): ['line 72 -> bus 7 (in_service=true)', 'line 74 -> bus 30 (in_service=true)', 'trafo 10 -> bus 26 (in_service=true)']
Bus 36 (380.0 kV, in_service=true): ['line 96 -> bus 53 (in_service=true)', 'trafo 19 -> bus 32 (in_service=true)']
Bus 37 (150.0 kV, in_service=true): ['line 128 -> bus 64 (in_service=true)']
Bus 38 (150.0 kV, in_service=true): ['line 23 -> bus 25 (in_service=true)', 'line 47 -> bus 41 (in_service=true)']
Bus 39 (150.0 kV, in_service=true): ['line 26 -> bus 25 (in_service=true)', 'line 38 -> bus 34 (in_service=true)', 'line 100 -> bus 32 (in_service=true)', 'line 108 -> bus 66 (in_service=true)', 'line 117 -> bus 64 (in_service=true)', 'line 118 -> bus 76 (in_service=true)', 'line 119 -> bus 45 (in_service=true)', 'line 120 -> bus 2 (in_service=true)', 'line 121 -> bus 27 (in_service=true)', 'line 122 -> bus 42 (in_service=true)', 'line 123 -> bus 40 (in_service=true)', 'line 124 -> bus 15 (in_service=true)', 'trafo 20 -> bus 73 (in_service=true)']
Bus 40 (150.0 kV, in_service=true): ['line 32 -> bus 25 (in_service=true)', 'line 45 -> bus 34 (in_service=true)', 'line 92 -> bus 5 (in_service=true)', 'line 115 -> bus 66 (in_service=true)', 'line 123 -> bus 39 (in_service=true)', 'line 134 -> bus 64 (in_service=true)', 'line 141 -> bus 76 (in_service=true)', 'line 146 -> bus 45 (in_service=true)', 'line 150 -> bus 2 (in_service=true)', 'line 157 -> bus 27 (in_service=true)', 'line 158 -> bus 42 (in_service=true)', 'trafo 27 -> bus 46 (in_service=true)', 'trafo 46 -> bus 0 (in_service=true)']
Bus 41 (150.0 kV, in_service=true): ['line 34 -> bus 34 (in_service=true)', 'line 46 -> bus 49 (in_service=true)', 'line 47 -> bus 38 (in_service=true)', 'line 70 -> bus 1 (in_service=true)', 'trafo 9 -> bus 58 (in_service=true)']
Bus 42 (150.0 kV, in_service=true): ['line 31 -> bus 25 (in_service=true)', 'line 44 -> bus 34 (in_service=true)', 'line 91 -> bus 5 (in_service=true)', 'line 114 -> bus 66 (in_service=true)', 'line 122 -> bus 39 (in_service=true)', 'line 133 -> bus 64 (in_service=true)', 'line 140 -> bus 76 (in_service=true)', 'line 145 -> bus 45 (in_service=true)', 'line 149 -> bus 2 (in_service=true)', 'line 156 -> bus 27 (in_service=true)', 'line 158 -> bus 40 (in_service=true)', 'trafo 26 -> bus 46 (in_service=true)', 'trafo 39 -> bus 12 (in_service=true)', 'trafo 47 -> bus 28 (in_service=true)']
Bus 43 (380.0 kV, in_service=true): ['line 1 -> bus 84 (in_service=true)', 'line 48 -> bus 29 (in_service=true)', 'line 49 -> bus 4 (in_service=true)', 'line 50 -> bus 8 (in_service=true)', 'line 51 -> bus 4 (in_service=true)', 'trafo 7 -> bus 18 (in_service=true)']
Bus 44 (150.0 kV, in_service=true): ['line 98 -> bus 32 (in_service=true)', 'line 104 -> bus 15 (in_service=true)']
Bus 45 (150.0 kV, in_service=true): ['line 28 -> bus 25 (in_service=true)', 'line 40 -> bus 34 (in_service=true)', 'line 111 -> bus 66 (in_service=true)', 'line 119 -> bus 39 (in_service=true)', 'line 130 -> bus 64 (in_service=true)', 'line 138 -> bus 76 (in_service=true)', 'line 143 -> bus 2 (in_service=true)', 'line 144 -> bus 30 (in_service=true)', 'line 145 -> bus 42 (in_service=true)', 'line 146 -> bus 40 (in_service=true)', 'line 147 -> bus 15 (in_service=true)', 'trafo 33 -> bus 68 (in_service=true)']
Bus 46 (220.0 kV, in_service=true): ['line 52 -> bus 18 (in_service=true)', 'line 125 -> bus 12 (in_service=true)', 'trafo 15 -> bus 5 (in_service=true)', 'trafo 22 -> bus 23 (in_service=true)', 'trafo 23 -> bus 64 (in_service=true)', 'trafo 24 -> bus 76 (in_service=true)', 'trafo 25 -> bus 27 (in_service=true)', 'trafo 26 -> bus 42 (in_service=true)', 'trafo 27 -> bus 40 (in_service=true)']
Bus 47 (380.0 kV, in_service=true): ['line 84 -> bus 4 (in_service=true)', 'line 93 -> bus 23 (in_service=true)', 'line 94 -> bus 67 (in_service=true)']
Bus 48 (380.0 kV, in_service=true): ['line 126 -> bus 72 (in_service=true)', 'line 136 -> bus 14 (in_service=true)', 'trafo 30 -> bus 76 (in_service=true)', 'trafo 31 -> bus 13 (in_service=true)']
Bus 49 (150.0 kV, in_service=true): ['line 33 -> bus 34 (in_service=true)', 'line 46 -> bus 41 (in_service=true)', 'trafo 6 -> bus 78 (in_service=true)']
Bus 50 (380.0 kV, in_service=true): ['line 97 -> bus 53 (in_service=true)']
Bus 51 (150.0 kV, in_service=true): ['line 14 -> bus 19 (in_service=true)', 'line 42 -> bus 34 (in_service=true)', 'line 76 -> bus 1 (in_service=true)', 'line 78 -> bus 60 (in_service=true)', 'line 154 -> bus 74 (in_service=true)', 'trafo 35 -> bus 69 (in_service=true)', 'trafo 41 -> bus 81 (in_service=true)']
Bus 52 (380.0 kV, in_service=true): ['line 152 -> bus 14 (in_service=true)', 'trafo 45 -> bus 65 (in_service=true)']
Bus 53 (380.0 kV, in_service=true): ['line 66 -> bus 20 (in_service=true)', 'line 96 -> bus 36 (in_service=true)', 'line 97 -> bus 50 (in_service=true)', 'trafo 48 -> bus 77 (in_service=true)', 'trafo 49 -> bus 21 (in_service=true)']
Bus 54 (380.0 kV, in_service=true): ['line 4 -> bus 61 (in_service=true)', 'line 5 -> bus 24 (in_service=true)', 'line 6 -> bus 63 (in_service=true)', 'line 7 -> bus 56 (in_service=true)', 'trafo 2 -> bus 87 (in_service=true)', 'trafo 3 -> bus 19 (in_service=true)']
Bus 55 (380.0 kV, in_service=true): ['line 83 -> bus 4 (in_service=true)', 'line 155 -> bus 3 (in_service=true)']
Bus 56 (380.0 kV, in_service=true): ['line 7 -> bus 54 (in_service=true)', 'line 67 -> bus 20 (in_service=true)', 'line 71 -> bus 26 (in_service=true)']
Bus 57 (220.0 kV, in_service=true): ['line 2 -> bus 18 (in_service=true)', 'line 3 -> bus 12 (in_service=true)', 'trafo 0 -> bus 84 (in_service=true)', 'trafo 1 -> bus 84 (in_service=true)']
Bus 58 (380.0 kV, in_service=true): ['line 69 -> bus 82 (in_service=true)', 'trafo 9 -> bus 41 (in_service=true)']
Bus 59 (380.0 kV, in_service=true): ['line 85 -> bus 4 (in_service=true)']
Bus 60 (150.0 kV, in_service=true): ['line 12 -> bus 19 (in_service=true)', 'line 16 -> bus 87 (in_service=true)', 'line 24 -> bus 25 (in_service=true)', 'line 36 -> bus 34 (in_service=true)', 'line 75 -> bus 1 (in_service=true)', 'line 77 -> bus 83 (in_service=true)', 'line 78 -> bus 51 (in_service=true)', 'trafo 11 -> bus 11 (in_service=true)', 'trafo 13 -> bus 69 (in_service=true)']
Bus 61 (380.0 kV, in_service=true): ['line 4 -> bus 54 (in_service=true)', 'trafo 18 -> bus 83 (in_service=true)']
Bus 62 (380.0 kV, in_service=true): ['line 63 -> bus 9 (in_service=true)', 'line 80 -> bus 4 (in_service=true)', 'line 153 -> bus 81 (in_service=true)']
Bus 63 (380.0 kV, in_service=true): ['line 6 -> bus 54 (in_service=true)', 'trafo 17 -> bus 22 (in_service=true)']
Bus 64 (150.0 kV, in_service=true): ['line 88 -> bus 5 (in_service=true)', 'line 101 -> bus 32 (in_service=true)', 'line 109 -> bus 66 (in_service=true)', 'line 117 -> bus 39 (in_service=true)', 'line 128 -> bus 37 (in_service=true)', 'line 129 -> bus 76 (in_service=true)', 'line 130 -> bus 45 (in_service=true)', 'line 131 -> bus 2 (in_service=true)', 'line 132 -> bus 27 (in_service=true)', 'line 133 -> bus 42 (in_service=true)', 'line 134 -> bus 40 (in_service=true)', 'line 135 -> bus 15 (in_service=true)', 'trafo 23 -> bus 46 (in_service=true)', 'trafo 28 -> bus 72 (in_service=true)', 'trafo 29 -> bus 12 (in_service=true)']
Bus 65 (380.0 kV, in_service=true): ['trafo 45 -> bus 52 (in_service=true)']
Bus 66 (150.0 kV, in_service=true): ['line 25 -> bus 25 (in_service=true)', 'line 37 -> bus 34 (in_service=true)', 'line 87 -> bus 5 (in_service=true)', 'line 99 -> bus 32 (in_service=true)', 'line 108 -> bus 39 (in_service=true)', 'line 109 -> bus 64 (in_service=true)', 'line 110 -> bus 76 (in_service=true)', 'line 111 -> bus 45 (in_service=true)', 'line 112 -> bus 2 (in_service=true)', 'line 113 -> bus 27 (in_service=true)', 'line 114 -> bus 42 (in_service=true)', 'line 115 -> bus 40 (in_service=true)', 'line 116 -> bus 15 (in_service=true)', 'trafo 21 -> bus 85 (in_service=true)']
Bus 67 (380.0 kV, in_service=true): ['line 94 -> bus 47 (in_service=true)', 'trafo 44 -> bus 79 (in_service=true)']
Bus 68 (380.0 kV, in_service=true): ['line 54 -> bus 16 (in_service=true)', 'line 56 -> bus 86 (in_service=true)', 'line 64 -> bus 6 (in_service=true)', 'line 65 -> bus 20 (in_service=true)', 'line 68 -> bus 6 (in_service=true)', 'line 106 -> bus 73 (in_service=true)', 'line 107 -> bus 85 (in_service=true)', 'line 127 -> bus 72 (in_service=true)', 'line 142 -> bus 24 (in_service=true)', 'trafo 33 -> bus 45 (in_service=true)', 'trafo 34 -> bus 2 (in_service=true)']
Bus 69 (220.0 kV, in_service=true): ['trafo 4 -> bus 19 (in_service=true)', 'trafo 13 -> bus 60 (in_service=true)', 'trafo 35 -> bus 51 (in_service=true)']
Bus 70 (380.0 kV, in_service=true): ['line 82 -> bus 4 (in_service=true)']
Bus 71 (150.0 kV, in_service=true): ['trafo 42 -> bus 81 (in_service=true)']
Bus 72 (380.0 kV, in_service=true): ['line 105 -> bus 73 (in_service=true)', 'line 126 -> bus 48 (in_service=true)', 'line 127 -> bus 68 (in_service=true)', 'trafo 28 -> bus 64 (in_service=true)']
Bus 73 (380.0 kV, in_service=true): ['line 105 -> bus 72 (in_service=true)', 'line 106 -> bus 68 (in_service=true)', 'trafo 20 -> bus 39 (in_service=true)']
Bus 74 (150.0 kV, in_service=true): ['line 154 -> bus 51 (in_service=true)']
Bus 75 (380.0 kV, in_service=true): ['line 79 -> bus 4 (in_service=true)', 'trafo 36 -> bus 12 (in_service=true)', 'trafo 37 -> bus 12 (in_service=true)']
Bus 76 (150.0 kV, in_service=true): ['line 27 -> bus 25 (in_service=true)', 'line 39 -> bus 34 (in_service=true)', 'line 89 -> bus 5 (in_service=true)', 'line 110 -> bus 66 (in_service=true)', 'line 118 -> bus 39 (in_service=true)', 'line 129 -> bus 64 (in_service=true)', 'line 137 -> bus 13 (in_service=true)', 'line 138 -> bus 45 (in_service=true)', 'line 139 -> bus 27 (in_service=true)', 'line 140 -> bus 42 (in_service=true)', 'line 141 -> bus 40 (in_service=true)', 'trafo 24 -> bus 46 (in_service=true)', 'trafo 30 -> bus 48 (in_service=true)', 'trafo 32 -> bus 12 (in_service=true)']
Bus 77 (150.0 kV, in_service=true): ['line 159 -> bus 15 (in_service=true)', 'trafo 48 -> bus 53 (in_service=true)']
Bus 78 (380.0 kV, in_service=true): ['line 18 -> bus 16 (in_service=true)', 'line 19 -> bus 9 (in_service=true)', 'line 20 -> bus 86 (in_service=true)', 'line 21 -> bus 82 (in_service=true)', 'trafo 5 -> bus 25 (in_service=true)', 'trafo 6 -> bus 49 (in_service=true)']
Bus 79 (380.0 kV, in_service=true): ['trafo 44 -> bus 67 (in_service=true)']
Bus 80 (380.0 kV, in_service=true): ['line 59 -> bus 10 (in_service=true)', 'line 60 -> bus 11 (in_service=true)', 'line 61 -> bus 82 (in_service=true)']
Bus 81 (380.0 kV, in_service=true): ['line 153 -> bus 62 (in_service=true)', 'trafo 41 -> bus 51 (in_service=true)', 'trafo 42 -> bus 71 (in_service=true)']
Bus 82 (380.0 kV, in_service=true): ['line 21 -> bus 78 (in_service=true)', 'line 61 -> bus 80 (in_service=true)', 'line 69 -> bus 58 (in_service=true)']
Bus 83 (150.0 kV, in_service=true): ['line 13 -> bus 19 (in_service=true)', 'line 17 -> bus 87 (in_service=true)', 'line 73 -> bus 7 (in_service=true)', 'line 77 -> bus 60 (in_service=true)', 'line 95 -> bus 22 (in_service=true)', 'trafo 18 -> bus 61 (in_service=true)']
Bus 84 (380.0 kV, in_service=true): ['line 1 -> bus 43 (in_service=true)', 'trafo 0 -> bus 57 (in_service=true)', 'trafo 1 -> bus 57 (in_service=true)']
Bus 85 (380.0 kV, in_service=true): ['line 107 -> bus 68 (in_service=true)', 'trafo 21 -> bus 66 (in_service=true)']
Bus 86 (380.0 kV, in_service=true): ['line 20 -> bus 78 (in_service=true)', 'line 56 -> bus 68 (in_service=true)', 'line 57 -> bus 0 (in_service=true)']
Bus 87 (150.0 kV, in_service=true): ['line 8 -> bus 19 (in_service=true)', 'line 15 -> bus 7 (in_service=true)', 'line 16 -> bus 60 (in_service=true)', 'line 17 -> bus 83 (in_service=true)', 'trafo 2 -> bus 54 (in_service=true)']
Bus 88 (380.0 kV, in_service=true): ['line 81 -> bus 4 (in_service=true)']

## B. Atomic Q-V controls

### Generator voltage controls
| index | bus | in_service | vm_pu | vm_min | vm_max | atomic_step |
|---|---|---|---|---|---|---|
| 0 | 20 | true | 1.039 | 0.950 | 1.050 | 0.010 |
| 1 | 23 | true | 1.039 | 0.950 | 1.050 | 0.010 |
| 2 | 36 | true | 1.050 | 0.950 | 1.050 | 0.010 |
| 3 | 41 | true | 1.048 | 0.950 | 1.050 | 0.010 |
| 4 | 44 | true | 1.050 | 0.950 | 1.050 | 0.010 |
| 5 | 55 | true | 1.050 | 0.950 | 1.050 | 0.010 |
| 6 | 59 | true | 1.050 | 0.950 | 1.050 | 0.010 |
| 7 | 64 | true | 1.034 | 0.950 | 1.050 | 0.010 |
| 8 | 70 | true | 1.050 | 0.950 | 1.050 | 0.010 |
| 9 | 80 | true | 1.024 | 0.950 | 1.050 | 0.010 |
| 10 | 88 | true | 1.050 | 0.950 | 1.050 | 0.010 |

### Shunt step controls
| index | bus | in_service | q_mvar_at_1pu | role | step | max_step |
|---|---|---|---|---|---|---|
| 0 | 0 | true | -4.5 | capacitor | 1 | 1 |
| 1 | 3 | true | 1.8 | reactor | 1 | 1 |
| 2 | 4 | true | -74.0 | capacitor | 1 | 1 |
| 3 | 8 | true | -0.6 | capacitor | 1 | 1 |
| 4 | 9 | true | -16.0 | capacitor | 1 | 1 |
| 5 | 10 | true | -20.8 | capacitor | 1 | 1 |
| 6 | 11 | true | 1.5 | reactor | 1 | 1 |
| 7 | 14 | true | -16.6 | capacitor | 1 | 1 |
| 8 | 15 | true | -0.6 | capacitor | 1 | 1 |
| 9 | 16 | true | -14.4 | capacitor | 1 | 1 |
| 10 | 17 | true | 1.5 | reactor | 1 | 1 |
| 11 | 21 | true | 5.6 | reactor | 1 | 1 |
| 12 | 24 | true | -22.7 | capacitor | 1 | 1 |
| 13 | 26 | true | -1.1 | capacitor | 1 | 1 |
| 14 | 28 | true | -3.8 | capacitor | 0 | 1 |
| 15 | 29 | true | -0.6 | capacitor | 1 | 1 |
| 16 | 30 | true | -0.6 | capacitor | 1 | 1 |
| 17 | 31 | true | -9.4 | capacitor | 1 | 1 |
| 18 | 35 | true | -0.6 | capacitor | 1 | 1 |
| 19 | 38 | true | -0.3 | capacitor | 1 | 1 |
| 20 | 43 | true | -50.9 | capacitor | 1 | 1 |
| 21 | 47 | true | -25.1 | capacitor | 1 | 1 |
| 22 | 48 | true | -17.3 | capacitor | 1 | 1 |
| 23 | 49 | true | -0.3 | capacitor | 1 | 1 |
| 24 | 50 | true | -2.2 | capacitor | 1 | 1 |
| 25 | 52 | true | 0.4 | reactor | 1 | 1 |
| 26 | 53 | true | -4.0 | capacitor | 1 | 1 |
| 27 | 54 | true | -35.4 | capacitor | 1 | 1 |
| 28 | 56 | true | -33.7 | capacitor | 1 | 1 |
| 29 | 58 | true | -0.7 | capacitor | 1 | 1 |
| 30 | 61 | true | -4.8 | capacitor | 1 | 1 |
| 31 | 62 | true | -21.2 | capacitor | 1 | 1 |
| 32 | 63 | true | -4.2 | capacitor | 1 | 1 |
| 33 | 67 | true | -6.2 | capacitor | 1 | 1 |
| 34 | 68 | true | -48.5 | capacitor | 1 | 1 |
| 35 | 72 | true | -19.1 | capacitor | 1 | 1 |
| 36 | 73 | true | -6.6 | capacitor | 1 | 1 |
| 37 | 75 | true | -2.0 | capacitor | 1 | 1 |
| 38 | 78 | true | -21.0 | capacitor | 1 | 1 |
| 39 | 81 | true | 0.9 | reactor | 1 | 1 |
| 40 | 82 | true | -16.4 | capacitor | 1 | 1 |
| 41 | 84 | true | -25.2 | capacitor | 1 | 1 |
| 42 | 85 | true | -3.1 | capacitor | 1 | 1 |
| 43 | 86 | true | -15.3 | capacitor | 1 | 1 |

### Transformer tap controls
| index | hv_bus | lv_bus | in_service | tap_side | tap_pos | tap_min | tap_max | tap_step_percent | atomic_step |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 84 | 57 | true | hv | -1 | -2 | 2 | 0.6 | 1 |
| 1 | 84 | 57 | true | hv | -1 | -2 | 2 | 0.2 | 1 |
| 2 | 54 | 87 | true | hv | -1 | -2 | 2 | 6.7 | 1 |
| 3 | 54 | 19 | true | hv | -1 | -2 | 2 | 8.8 | 1 |
| 5 | 78 | 25 | true | hv | -1 | -2 | 2 | 8.0 | 1 |
| 6 | 78 | 49 | true | hv | -1 | -2 | 2 | 5.2 | 1 |
| 7 | 43 | 18 | true | hv | -1 | -2 | 2 | 0.3 | 1 |
| 9 | 58 | 41 | true | hv | -1 | -2 | 2 | 7.7 | 1 |
| 10 | 26 | 35 | true | hv | -1 | -2 | 2 | 4.8 | 1 |
| 11 | 11 | 60 | true | hv | -1 | -2 | 2 | 7.6 | 1 |
| 12 | 17 | 1 | true | hv | -1 | -2 | 2 | 6.5 | 1 |
| 14 | 4 | 33 | true | hv | -1 | -2 | 2 | 1.3 | 1 |
| 17 | 63 | 22 | true | hv | -1 | -2 | 2 | 7.6 | 1 |
| 18 | 61 | 83 | true | hv | -1 | -2 | 2 | 9.9 | 1 |
| 19 | 36 | 32 | true | hv | -1 | -2 | 2 | 7.7 | 1 |
| 20 | 73 | 39 | true | hv | -1 | -2 | 2 | 7.6 | 1 |
| 21 | 85 | 66 | true | hv | -1 | -2 | 2 | 6.5 | 1 |
| 22 | 23 | 46 | true | hv | -1 | -2 | 2 | 3.3 | 1 |
| 28 | 72 | 64 | true | hv | -1 | -2 | 2 | 6.5 | 1 |
| 30 | 48 | 76 | true | hv | 0 | -2 | 2 | 4.4 | 1 |
| 31 | 48 | 13 | true | hv | -1 | -2 | 2 | 3.2 | 1 |
| 33 | 68 | 45 | true | hv | -1 | -2 | 2 | 8.1 | 1 |
| 34 | 68 | 2 | true | hv | -1 | -2 | 2 | 5.1 | 1 |
| 36 | 75 | 12 | true | hv | -1 | -2 | 2 | 3.3 | 1 |
| 37 | 75 | 12 | true | hv | -1 | -2 | 2 | 3.3 | 1 |
| 40 | 24 | 30 | true | hv | -1 | -2 | 2 | 6.5 | 1 |
| 41 | 81 | 51 | true | hv | -1 | -2 | 2 | 8.7 | 1 |
| 42 | 81 | 71 | true | hv | 1 | -2 | 2 | 1.2 | 1 |
| 43 | 3 | 27 | true | hv | -1 | -2 | 2 | 6.7 | 1 |
| 46 | 0 | 40 | true | hv | -1 | -2 | 2 | 7.6 | 1 |
| 47 | 28 | 42 | true | hv | -1 | -2 | 2 | 6.7 | 1 |
| 48 | 53 | 77 | true | hv | -1 | -2 | 2 | 7.7 | 1 |

## C. Operating context

### Loads (read-only)
| index | bus | in_service | p_mw | q_mvar |
|---|---|---|---|---|
| 0 | 2 | true | 124.2 | 34.4 |
| 1 | 5 | true | 456.0 | 64.7 |
| 2 | 7 | true | 245.4 | 153.4 |
| 3 | 10 | true | 196.8 | -2.6 |
| 4 | 12 | true | 366.9 | 324.6 |
| 5 | 15 | true | 354.1 | 215.1 |
| 6 | 18 | true | 106.8 | 16.3 |
| 7 | 19 | true | 144.6 | 167.3 |
| 8 | 22 | true | 8.8 | -1.5 |
| 9 | 25 | true | 536.5 | 147.0 |
| 10 | 27 | true | 413.9 | -141.5 |
| 11 | 30 | true | 247.0 | 73.9 |
| 12 | 31 | true | 461.0 | 4.7 |
| 13 | 32 | true | 385.5 | 107.2 |
| 14 | 34 | true | 303.4 | 81.9 |
| 15 | 39 | true | 393.2 | 102.9 |
| 16 | 40 | true | 470.6 | 146.1 |
| 17 | 42 | true | 542.3 | 86.8 |
| 18 | 43 | true | 57.5 | 13.5 |
| 19 | 45 | true | 547.0 | 223.4 |
| 20 | 46 | true | 529.9 | 113.4 |
| 21 | 51 | true | 280.4 | 101.4 |
| 22 | 57 | true | 526.3 | -218.8 |
| 23 | 60 | true | 412.4 | -103.8 |
| 24 | 66 | true | 735.5 | -17.7 |
| 25 | 71 | true | 39.8 | -10.8 |
| 26 | 76 | true | 875.6 | 191.6 |
| 27 | 83 | true | 899.8 | 143.8 |
| 28 | 87 | true | 18.3 | 23.8 |

### Generation P (read-only)
| index | bus | in_service | p_mw | min_p_mw | max_p_mw |
|---|---|---|---|---|---|
| 0 | 20 | true | 1817.0 | 500.0 | 2250.0 |
| 1 | 23 | true | 518.2 | 166.7 | 750.0 |
| 2 | 36 | true | 1570.8 | 666.7 | 3000.0 |
| 3 | 41 | true | -545.7 | -545.7 | -545.7 |
| 4 | 44 | true | 30.2 | 7.1 | 31.8 |
| 5 | 55 | true | 1259.0 | 400.0 | 1800.0 |
| 6 | 59 | true | 1359.4 | 333.3 | 1500.0 |
| 7 | 64 | true | -681.7 | -681.7 | -681.7 |
| 8 | 70 | true | 599.7 | 200.0 | 900.0 |
| 9 | 80 | true | 611.2 | 200.0 | 900.0 |
| 10 | 88 | true | 599.7 | 200.0 | 900.0 |

### External-grid limits (read-only)
| index | bus | in_service | vm_pu | min_p_mw | max_p_mw | min_q_mvar | max_q_mvar |
|---|---|---|---|---|---|---|---|
| 0 | 6 | true | 1.031 | 566.7 | 1700.0 | -269.9 | 2500.0 |
